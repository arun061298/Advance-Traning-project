package com.advance;

public abstract class Instrument {
	public abstract void play();
}
